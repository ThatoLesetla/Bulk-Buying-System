<?php
$value = $_GET['productID'];

echo $value;
?>